import './App.css';

import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { Home,Mesajes,Conferencia } from './pages';

function App() {
  return (
    <div className="App">
        <Router>
          <AuthProvider>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/mensajes" element={<Mesajes />} />
              <Route path="/conferencia" element={<Conferencia />} />
            </Routes>
          </AuthProvider>
        </Router>
    </div>
  );
}

export default App;
