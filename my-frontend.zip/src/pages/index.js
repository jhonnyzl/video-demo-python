export {default as Home} from './Home.jsx';
export {default as Mesajes} from './Mesajes.jsx';
export {default as Conferencia} from './conferencia.jsx';