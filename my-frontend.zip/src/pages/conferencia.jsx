import React, { useEffect, useState } from 'react';
import VideoRecorder from '../components/VideoRecorder';

import './conferencia.css';
const Conferencia = () => {
    const [permissionsGranted, setPermissionsGranted] = useState(false);
    const [conversationUrl, setConversationUrl] = useState('');
    const [conversationId, setConversationId] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const requestPermissions = async () => {
            try {
                const cameraPermission = await navigator.mediaDevices.getUserMedia({ video: true });
                const microphonePermission = await navigator.mediaDevices.getUserMedia({ audio: true });
                if (cameraPermission && microphonePermission) {
                    setPermissionsGranted(true);
                }
            } catch (error) {
                console.error('Permissions denied', error);
                setPermissionsGranted(false);
            }
        };

        requestPermissions();
    }, []);

    useEffect(() => {
        const fetchConversation = async () => {
            try {
                const response = await fetch('http://localhost:8000/ejecutar-crear-conversacion/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const data = await response.json();
                /*
                {
                    "conversation_id": "c62223be",
                    "conversation_name": "New Conversation 1724946127496",
                    "conversation_url": "https://tavus.daily.co/c62223be",
                    "status": "active",
                    "callback_url": null,
                    "created_at": "2024-08-29T15:42:07.514Z"
                }
                */
                setConversationId(data.conversation_id);
                console.log(data.conversation_id)
                setConversationUrl(data.conversation_url);
            } catch (error) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchConversation();
    }, []);

    //verificar cambios del html y obtener el boton de Join
    if (!permissionsGranted) {
        return <div>Please grant camera and microphone permissions to continue.</div>;
    }

    if (loading) {
        return <p>Cargando...</p>;
    }

    if (error) {
        return <p>Error: {error}</p>;
    }

    return (
        <div>
            <h1>Conversación</h1>
            <VideoRecorder conversationId={conversationId}/>
            {conversationUrl ? (
                <div>
                    <iframe title='Test' src={conversationUrl} width="100%" height="500px" style={{ border: 'none' }} allow="camera; microphone"></iframe>
                </div>
            ) : (
                <p>No se pudo obtener la URL de la conversación.</p>
            )}
        </div>
    );
};

export default Conferencia;